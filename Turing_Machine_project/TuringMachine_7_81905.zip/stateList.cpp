#include "stateList.h"
#include <fstream>
#include<vector>
#include<cassert>




void state::getState(std::string filename)
{
	std::ifstream is;
	std::string newName, newT, newF;
	char newSymbol, newWriteSymbolT, newWriteSymbolIF, newDirT, newDirF;

	is.open(filename);
	is >> newName;
	is >> newSymbol;
	is >> newWriteSymbolT;
	is >> newWriteSymbolIF;
	is >> newDirT;
	is >> newDirF;
	is >> newT;
	is >> newF;

	name = newName;
	stateSymbol = newSymbol;
	rule.giveRules(newWriteSymbolT, newDirT);
	ruleIfFalse.giveRules(newWriteSymbolIF, newDirF);
	nextStateName = newT;
	nextStateNameIfFalse = newF;

	is.close();

}
//�� �������� �� ��� �����������: �� ��������� �� ������ � �� ��������� �� ����
void stateList::copy(stateList& other)
{
	if (Start == nullptr) {
		Start = other.Start;
	}

	if (other.Start == nullptr) {
		return;
	}


	for (size_t i = 0; i < other.stateBuffer.size(); i++) {
		this->stateBuffer[i] = other.stateBuffer[i];
	}

	
}

void stateList::clear()
{

	if(stateBuffer.size()!=0)stateBuffer.clear();
	if(Start!=nullptr)delete Start;
	if(Final!=nullptr)delete Final;
}

stateList::stateList()
{
	//Start = new state("Start",0, state_rule(),nullptr," ");
	Start = nullptr;
	Final = new state("halt", 0, state_rule(), state_rule(),"","");
}

stateList& stateList::operator=(stateList& other)
{
	if (this != &other) {
		this->clear();
		this->copy(other);

	}
	return *this;
}

stateList::~stateList()
{
	clear();
}

//������� ��������� ������ �� ���� ��������� � ��� �� ���������� ��������� halt
void stateList::setStates(std::string filename)
{
	
	std::ifstream is;
	is.open(filename);
	std::string newName, newT,newF;
	char newSymbol, newWriteSymbolT,newWriteSymbolIF,newDirT,newDirF;

	//��������� ����� �� ���������� ���������
	if (Start == nullptr) {
		is >> newName;
		is >> newSymbol;
		is >> newWriteSymbolT;
		is >> newWriteSymbolIF;
		is >> newDirT;
		is >> newDirF;
		is >> newT;
		is >> newF;
		Start = new state(newName, newSymbol, state_rule(newWriteSymbolT, newDirT),
			state_rule(newWriteSymbolIF,newDirF),newT,newF);
		
		stateBuffer.push_back(Start);
	}
	// ��������� ����� �� ������� ���������
	state* newlyCreated = nullptr;
	while (is.eof() == false) {

		is >> newName;
		is >> newSymbol;
		is >> newWriteSymbolT;
		is >> newWriteSymbolIF;
		is >> newDirT;
		is >> newDirF;
		is >> newT;
		is >> newF;
		newlyCreated = new state(newName, newSymbol, state_rule(newWriteSymbolT, newDirT),
			state_rule(newWriteSymbolIF,newDirF),newT,newF);
		stateBuffer.push_back(newlyCreated);

	}
	stateBuffer.push_back(Final);
	is.close();

}

void stateList::setFalseStates(std::string filename)
{
	std::string newF;
	std::ifstream is;
	is.open(filename);
	size_t index=0;

	while (is.eof() == false) {
		is >> newF;
		stateBuffer[index]->nextStateNameIfFalse = newF;
		index++;
	}
	is.close();

}



state* stateList::getStart()
{
	return Start;
}

void stateList::setStart(state* newStart)
{
	Start = newStart;
}

state* stateList::getFinal()
{
	return Final;
}

bool stateList::isThereAState(std::string Name) {

	for (size_t i = 0; i < stateBuffer.size(); i++) {
		if (stateBuffer[i]->name == Name) {
			return true;
		}
	}

	return false;
}

state* stateList::getStateByName(std::string Name) {
	for (size_t i = 0; i < stateBuffer.size(); i++) {
		if (stateBuffer[i]->name == Name) {
			return stateBuffer[i];
		}
	}
}

void stateList::printList()
{
	for(size_t i =0;i<stateBuffer.size();i++) {
		std::cout << stateBuffer[i]->name << " ";
		std::cout << stateBuffer[i]->stateSymbol << " ";
		std::cout << stateBuffer[i]->rule.writeNewSymbol << " ";
		std::cout << stateBuffer[i]->rule.direction <<" ";
		std::cout << stateBuffer[i]->ruleIfFalse.direction << " ";
		std::cout << stateBuffer[i]->nextStateName << " ";
		std::cout << stateBuffer[i]->nextStateNameIfFalse << std::endl;
	}
}


