//#include "stateList.h"
//#include <fstream>
//
//
//void state::getState(std::string filename)
//{
//	std::ifstream is;
//	std::string newName, newT;
//	char newSymbol, newWriteSymbolT, newDirT;
//
//	is.open(filename);
//	is >> newName;
//	is >> newSymbol;
//	is >> newWriteSymbolT;
//	is >> newDirT;
//	is >> newT;
//	rule.giveRules(newWriteSymbolT, newDirT);
//	stateSymbol = newSymbol;
//	name = newName;
//	nextStateName = newT;
//
//
//	is.close();
//
//}
//
//void stateList::copy(stateList& other)
//{
//	if (Start == nullptr) {
//		Start = other.Start;
//	}
//
//	if (other.Start == nullptr) {
//		return;
//	}
//
//
//	state* newElement = nullptr;
//	state* lastCreated = Start;
//	state* curr2 = other.Start->nextState;
//
//	while (curr2->nextState != nullptr) {
//		newElement = new state(curr2->name, curr2->stateSymbol, curr2->rule, curr2->nextState, curr2->nextStateName);
//		lastCreated->nextState = newElement;
//		curr2 = curr2->nextState;
//		lastCreated = newElement;
//	}
//
//
//}
//
//void stateList::clear()
//{
//	state* current = Start;
//	state* tobeDel = Start;
//	while (current->nextState != nullptr) {
//		tobeDel = current;
//		delete current;
//		tobeDel = current->nextState;
//	}
//
//	delete Final;
//}
//
//stateList::stateList()
//{
//	//Start = new state("Start",0, state_rule(),nullptr," ");
//	Start = nullptr;
//	Final = new state("halt", 0, state_rule(), nullptr, " ");
//}
//
//stateList& stateList::operator=(stateList& other)
//{
//	if (this != &other) {
//		this->clear();
//		this->copy(other);
//
//	}
//	return *this;
//}
//
//stateList::~stateList()
//{
//	clear();
//}
//
////������� ��������� ������ �� ���� ��������� � ��� �� ���������� ��������� halt
//void stateList::setStates(std::string filename)
//{
//
//	std::ifstream is;
//	is.open(filename);
//	std::string newName, newT;
//	char newSymbol, newWriteSymbolT, newDirT;
//
//	if (Start == nullptr) {
//		is >> newName;
//		is >> newSymbol;
//		is >> newWriteSymbolT;
//		is >> newDirT;
//		is >> newT;
//		Start = new state(newName, newSymbol, state_rule(newWriteSymbolT, newDirT), nullptr, newT);
//	}
//
//	state* current = Start;
//	state* newlyCreated = nullptr;
//	while (current->nextStateName != "halt") {
//
//		is >> newName;
//		is >> newSymbol;
//		is >> newWriteSymbolT;
//		is >> newDirT;
//		is >> newT;
//		newlyCreated = new state(current->nextStateName, newSymbol, state_rule(newWriteSymbolT, newDirT), nullptr, newT);
//		current->nextState = newlyCreated;
//		current = newlyCreated;
//	}
//	current->nextState = Final;
//
//	is.close();
//
//}
//
//state* stateList::getStart()
//{
//	return Start;
//}
//
//
//
//void stateList::printList()
//{
//	state* current = Start;
//	while (current->name != "halt") {
//		std::cout << current->name << " ";
//		std::cout << current->stateSymbol << " ";
//		std::cout << current->rule.writeNewSymbol << " ";
//		std::cout << current->rule.direction << std::endl;
//		current = current->nextState;
//	}
//}