// Turing_Machine_project.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <fstream>
#include "Tape.h"
#include"stateList.h"
#include "TuringMachine.h"


void tapeTest() {
    Tape T;
    T.input("inputTape1.txt");
    T.output("outputTape1.txt");
    T.print();
}
void stateTest() {
    stateList L;
    L.setStates("inputStates2.txt");
    L.setFalseStates("inputFalseStates1.txt");
    L.printList();
}

void TMTest() {
    TuringMachine T;
    T.getData( "inputStates2.txt","inputFalseStates1.txt", "inputTape1.txt");
    T.proccess("TMoutput.txt");
    
}

void ConcTest() {
    TuringMachine A, B;
    A.getData("inputStates.txt","inputFalseStates.txt", "inputTape1.txt");
    B.getData("inputStates2.txt","inputFalseStates1.txt","inputTape2.txt");
    A.concat(B);
    A.proccess("TMoutput.txt");
    A.getStateList().printList();
   // A.returnTape().print();
 
    
}

void TMswitcher() {
    TuringMachine A, B, C;
    std::string key;
    std::cout << "Enter a key,so the program could know which input is true!: ";
    std::cin >> key;
    A.machineSwitcher(B, C,key, "inputStates2.txt", "inputFalseStates1.txt", "inputStates.txt", "inputFalseStates.txt",
        "inputStates2.txt", "inputFalseStates1.txt", "inputTape1.txt");
}

int main()
{
   // tapeTest();
   // stateTest();
    //TMTest();
   //ConcTest();
    TMswitcher();
}

